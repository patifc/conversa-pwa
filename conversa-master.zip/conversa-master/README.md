<h1>Conversa app</h1>

<the project description goes here>

<h2>Built With </h2>

 .HTML
 .CSS
 .JavaScript

<h2> Authors </h2>

.Leandro
.Lucas
.Patricia 
.Richard
.Willian